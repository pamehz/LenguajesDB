<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel='stylesheet' href='css/bootstrap.min.css'>
    <link rel='stylesheet' href='css/estilos.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Staatliches&display=swap" rel="stylesheet">
    <title>Document</title>
</head>
<h1 style="color: white;">Librería LBD</h1>
<body class="bg-primary bg-opacity-25">

    <main class="contenedor">
        <div class="nav-bg">
            <nav class="navegacion">
                
            <a class="navegacion__enlace navegacion__enlace--activo" href="index.html">Inicio |</a>
                <a class="navegacion__enlace" href="category.html">Categorías</a>
                <a class="navegacion__enlace" href="newform copy.html">| Ingresar</a>
                <a class="navegacion__enlace" href="Soporte2.html">| Búsqueda de Libros</a>
                <a class="navegacion__enlace" href="procesar-form3.php">| Calendario de Actividades</a>

            </nav>