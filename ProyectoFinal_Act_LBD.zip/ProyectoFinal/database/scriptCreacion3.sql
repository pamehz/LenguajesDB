CREATE TABLE usuario (
    id NUMBER(11) PRIMARY KEY,
    nombre VARCHAR2(50) NOT NULL,
    tel VARCHAR2(50) NOT NULL,
    correo VARCHAR2(50) NOT NULL
);
