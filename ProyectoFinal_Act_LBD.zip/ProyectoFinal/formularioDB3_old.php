<?php
require 'include/funciones.php';
incluirTemplate('header');

$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'include/funciones/recogeRequest.php';

    $nombre = recogePost("nombre");
    $apellido1 = recogePost("apellido1");
    $apellido2 = recogePost("apellido2");
    $genero = recogePost("genero");
    $correo = recogePost("correo");
    $tel = recogePost("tel");

    $nombreOK = false;
    $apellido1OK = false;
    $apellido2OK = false;
    $generoOK = false;
    $correoOK = false;
    $telOK = false;

    if ($nombre === "") {
        $errores[] = "No digitó el nombre del participante";
    } else {
        $nombreOK = true;
    }

    // Puedes decidir si el apellido1 es obligatorio o no
    if ($apellido1 === "") {
        $errores[] = "No digitó el primer apellido del participante";
    } else {
        $apellido1OK = true;
    }

    // Puedes decidir si el apellido2 es obligatorio o no
    if ($apellido2 === "") {
        $errores[] = "No digitó el segundo apellido del participante";
    } else {
        $apellido2OK = true;
    }

    if ($genero === "") {
        $errores[] = "No digitó el género del participante";
    } else {
        $generoOK = true;
    }

    if ($correo === "") {
        $errores[] = "No digitó el correo del participante";
    } else {
        $correoOK = true;
    }

    if ($tel === "") {
        $errores[] = "No digitó el teléfono del participante";
    } else {
        $telOK = true;
    }

    if ($nombreOK && $apellido1OK && $apellido2OK && $generoOK && $correoOK && $telOK) {
        // Ingresar los datos a la base de datos
        require_once 'DAL/usuario3_oracle.php';
        // Ajustar según la estructura de tu tabla en la base de datos
        if (InsercionAutor($nombre, $apellido1, $apellido2, $genero, $correo, $tel)) {
            header("Location: consulta-datos3.php");
        }
    }
}
?>

<main class="contenedor">
    <h1 class="text-white">Librería LBD</h1>

    <div class="contendor-estetica">
        <header class="header">
            <h2 class="text-white">Sección de Información <i class="fa-solid fa-sitemap fa-fade fa-1x" style="color: #000000;"></i></h2><br><br><br>
            <div>
                <center>
                    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
                </center>
            </div>
        </header>

        <?php foreach ($errores as $error): ?>
            <div class="alerta error">
                <?php echo $error; ?>
            </div>
        <?php endforeach; ?>

        <form method="POST">
            <?php incluirTemplate('formulario3'); ?>
            <button type="submit">Participar</button>
        </form>
    </div>
</main>
