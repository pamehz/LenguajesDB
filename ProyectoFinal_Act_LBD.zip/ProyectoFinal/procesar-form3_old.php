<?php 
require_once 'include/funciones/recogeRequest.php';

$nombre = recogePost("nombre");
$apellido1 = recogePost("apellido1");
$apellido2 = recogePost("apellido2");
$genero = recogePost("genero");

$nombreOK = false;
$apellido1OK = false;
$apellido2OK = false;
$generoOK = false;

$errores = [];

if ($nombre === "") {
    $errores[] = "No digitó el nombre del autor";
} else {
    $nombreOK = true;
}

if ($apellido1 === "") {
    $errores[] = "No digitó el primer apellido del autor";
} else {
    $apellido1OK = true;
}

// Puedes decidir si el segundo apellido es obligatorio o no
if ($apellido2 === "") {
    $errores[] = "No digitó el segundo apellido del autor";
} else {
    $apellido2OK = true;
}


if ($genero === "") {
    $errores[] = "No digitó el género del autor";
} else {
    $generoOK = true;
}

if ($nombreOK && $apellido1OK && $generoOK) {
    // Ingresar los datos a la base de datos Oracle
    require_once 'DAL/usuario3_oracle.php';

    if (InsercionAutor($nombre, $apellido1, $apellido2, $genero)) {
        header("Location: consulta-datos3.php");
    }
} else {
    require_once 'formularioDB3.php';
}
?>

