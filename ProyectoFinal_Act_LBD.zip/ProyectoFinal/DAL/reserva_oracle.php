<?php

require 'include/funciones.php';
incluirTemplate('header');

$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'include/funciones/recogeRequest.php';

    $id_libro = recogePost("id");
    $fecha_reserva = recogePost("date");
    $id_reserva = recogePost("reserva libro"); 

    $id_libroOK = false;
    $fecha_reservaOK = false;
    $numero_copiasOK = false;
    $id_reservaOK = false;

    if ($id_libro === "") {
        $errores[] = "No digitó el id";
    } else {
        $id_libroOK = true;
    }

    if ($titulo_libro === "") {
        $errores[] = "No digitó el título";
    } else {
        $titulo_libroOK = true;
    }

    if ($fecha_reserva === "") {
        $errores[] = "No digitó la fecha de publicación";
    } else {
        $fecha_reservaOK = true;
    }

    if ($id_reserva === "") {
        $errores[] = "No seleccionó el id";
    } else {
        $id_reservaOK = true;
    }

    if ($id_libroOK && $fecha_reservaOK && $id_reservaOK) {
        //ingresar los datos a base de datos
        require_once 'DAL/reserva_oracle.php';
        if (InsercionAutor($id_libro, $fecha_reserva, $id_reserva)) {
            header("Location: consulta-datosR.php");
        }
    }
}
?>