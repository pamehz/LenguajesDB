<?php

//  function Conecta() {
//     $server = "localhost";
//     $user = "root";
//     $password = "";
//     $dataBase = "usuarios";

//     //1. Establecer la conexión con el motor de base de datos
//     $conexion = mysqli_connect($server, $user, $password, $dataBase);

//     if(!$conexion){
//         echo "Error al establecer la conexión: " . mysqli_connect_error();
//     }

//     return $conexion;
// }

// function Desconecta($conexion) {
//     // ultimo paso
//     mysqli_close($conexion);
// } 


function Conecta() {
     $servidor = "localhost"; 
    $usuario = "lbd_user"; 
    $contrasena = "12345"; 
     $sid = "ORCL"; 

    $conexion = oci_connect($usuario, $contrasena, "(DESCRIPTION=(ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = $servidor)(PORT = 1521)))(CONNECT_DATA=(SID = $sid)))");

     if (!$conexion) {
         $error = oci_error();
         echo "Error al establecer la conexión: " . $error['message'];
     }

     return $conexion;
 }

 function Desconecta($conexion) {
     oci_close($conexion);
}

<?php



