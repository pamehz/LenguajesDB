<?php

function Conecta() {
    $servidor = "localhost";
    $usuario = "lbd_user";
    $contrasena = "12345";
    $sid = "ORCL";

    $conexion = oci_connect($usuario, $contrasena, "$servidor/$sid");

    if (!$conexion) {
        $e = oci_error();
        echo "Error al establecer la conexión: " . $e['message'];
    }

    return $conexion;
}

function Desconecta($conexion) {
    oci_close($conexion);
}

?>
