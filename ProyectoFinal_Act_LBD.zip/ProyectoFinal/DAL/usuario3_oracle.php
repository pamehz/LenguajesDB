<?php

require 'include/funciones.php';
incluirTemplate('header');

$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'include/funciones/recogeRequest.php';

    $nombre = recogePost("nombre");
    $apellido1 = recogePost("apellido1");
    $apellido2 = recogePost("apellido2");
    $genero = recogePost("genero"); 

    $nombreOK = false;
    $correoOK = false;
    $telOK = false;
    $generoOK = false;

    if ($nombre === "") {
        $errores[] = "No digitó el nombre";
    } else {
        $nombreOK = true;
    }

    if ($apellido1 === "") {
        $errores[] = "No digitó el apellido";
    } else {
        $apellido1 = true;
    }

    if ($apellido2 === "") {
        $errores[] = "No digitó el apellido";
    } else {
        $apellido2 = true;
    }

    if ($genero === "") {
        $errores[] = "No seleccionó el género del participante";
    } else {
        $generoOK = true;
    }

    if ($nombreOK && $apellido1OK && $apellido2OK && $generoOK) {
        //ingresar los datos a base de datos
        require_once 'DAL/usuario3_oracle.php';
        if (InsercionAutor($nombre, $apellido1, $apellido2, $genero)) {
            header("Location: consulta-datos3.php");
        }
    }
}

?>