<?php

require 'include/funciones.php';
incluirTemplate('header');

$errores = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'include/funciones/recogeRequest.php';

    $cedula_cliente = recogePost("cedula");
    $nombre_cliente = recogePost("nombre cliente");
    $apellido_materno = recogePost("apellido materno");
    $apellido_paterno = recogePost("apellido paterno"); 
    $fecha_nacimiento = recogePost("día de nacimiento");
    $id_reserva = recogePost("día de nacimiento"); 

    $id_libroOK = false;
    $titulo_libroOK = false;
    $fecha_publicacionOK = false;
    $numero_copiasOK = false;
    $id_generoOK = false;

    if ($id_libro === "") {
        $errores[] = "No digitó el id";
    } else {
        $id_libroOK = true;
    }

    if ($titulo_libro === "") {
        $errores[] = "No digitó el título";
    } else {
        $titulo_libroOK = true;
    }

    if ($fecha_publicacion === "") {
        $errores[] = "No digitó la fecha de publicación";
    } else {
        $fecha_publicacionOK = true;
    }

    if ($numero_copias === "") {
        $errores[] = "No seleccionó el total";
    } else {
        $numero_copias = true;
    }

    if ($id_genero === "") {
        $errores[] = "No seleccionó el genero";
    } else {
        $id_generoOK = true;
    }

    if ($id_libroOK && $titulo_libroOK && $fecha_publicacionOK && $numero_copiasOK && $id_generoOK) {
        //ingresar los datos a base de datos
        require_once 'DAL/libro_oracle.php';
        if (InsercionAutor($id_libro, $titulo_libro, $fecha_publicacion, $numero_copias, $id_genero)) {
            header("Location: consulta-datosL.php");
        }
    }
}

?>