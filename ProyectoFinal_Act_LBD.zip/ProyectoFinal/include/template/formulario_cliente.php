<div class="d-flex flex-column min-vh-100 justify-content-center">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-8 col-lg-6 mx-auto bg-white rounded shadow p-5">
                <div class="text-center mb-4">
                    <h1>Libros"</h1>
                    <center>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
                            integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
                            crossorigin="anonymous" referrerpolicy="no-referrer" />

                        <i class="fa-solid fa-dharmachakra fa-spin fa-spin-reverse fa-4x" style="color: #000000;"></i>
                    </center>

                    <p>Libros</p>
                    
                </div>
                <form action="procesar-form3.php" method="POST" class="needs-validation" novalidate>
                    <div class="mb-3">
                        <label class="form-label" for="cedula_cliente">Numero de cédula:</label>
                        <input class="form-control" type="text" name="cedula_cliente" id="cedula_cliente" placeholder="Digite su cédula" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="nombre_cliente">Nombre del cliente:</label>
                        <input class="form-control" type="text" name="nombre_cliente" id="nombre_cliente" placeholder="Digite su nombre" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="id_genero">Apellido paterno:</label>
                        <input class="form-control" type="text" name="apellido_paterno" id="apellido_paterno" placeholder="Digite su primer apellido" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="id_genero">Apellido materno:</label>
                        <input class="form-control" type="text" name="apellido_materno" id="apellido_materno" placeholder="Digite su segundo apellido" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="id_genero">Fecha de nacimiento:</label>
                        <input class="form-control" type="text" name="f_nacimiento" id="f_nacimiento" placeholder="Digite el día, mes y año de nacimiento" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="id_genero">ID de reserva asignado:</label>
                        <input class="form-control" type="text" name="id_reserva" id="id_reserva" placeholder="Digite el día, mes y año de nacimiento" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    </div>
                    <button class="btn btn-primary" type="submit">¡Enviar!</button>
                </form>
            </div>
        </div>
    </div>
</div>
