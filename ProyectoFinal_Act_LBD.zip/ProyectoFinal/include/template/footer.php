
<footer class="footer">
        <p class="footer__texto">SC-504 Lenguaje de bases de datos - Todos los
        derechos Reservados 2023.</p>
    </footer>
    <script src="js/app.js"></script>
</body>

</html>