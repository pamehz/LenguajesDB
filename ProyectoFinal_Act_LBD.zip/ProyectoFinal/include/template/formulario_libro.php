<div class="d-flex flex-column min-vh-100 justify-content-center">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-md-8 col-lg-6 mx-auto bg-white rounded shadow p-5">
                <div class="text-center mb-4">
                    <h1>Libros"</h1>
                    <center>
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
                            integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
                            crossorigin="anonymous" referrerpolicy="no-referrer" />

                        <i class="fa-solid fa-dharmachakra fa-spin fa-spin-reverse fa-4x" style="color: #000000;"></i>
                    </center>

                    <p>Libros</p>
                    
                </div>
                <form action="procesar-form3.php" method="POST" class="needs-validation" novalidate>
                    <div class="mb-3">
                        <label class="form-label" for="titulo_libro">Nombre completo del libro:</label>
                        <input class="form-control" type="text" name="nombre" id="nombre" placeholder="Digite el nombre del libro" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="fecha_publicacion">Fecha de publicacion del libro:</label>
                        <input class="form-control" type="text" name="f_libro" id="f_libro" placeholder="Digite la fecha de publicación del libro" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label" for="id_genero">Género del libro:</label>
                        <input class="form-control" type="text" name="g_libro" id="g_libro" placeholder="Digite el género del libro" required />
                        <div class="invalid-feedback">Por favor ingresa datos válidos.</div>
                    </div>
                    </div>
                    <button class="btn btn-primary" type="submit">¡Enviar!</button>
                </form>
            </div>
        </div>
    </div>
</div>
