
<footer class="footer">
        <p class="footer__texto">SC-502 Ambiente Web Cliente Servidor - Todos los derechos Reservados 2023.</p>
    </footer>
    <script src="js/app.js"></script>
</body>

</html>