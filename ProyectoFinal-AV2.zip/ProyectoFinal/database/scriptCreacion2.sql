CREATE TABLE `users`.`actualizados` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `Nombre` VARCHAR(50) NOT NULL,
    `Correo` VARCHAR(50) NOT NULL,
    `Issue` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`id`)
) ENGINE = InnoDB;